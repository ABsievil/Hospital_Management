select concat(upper(ename), 'is the name')
as EmployeeName
from emp
where sal > 0
order by ename desc;
